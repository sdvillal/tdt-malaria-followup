General remarks
--------------------------------------

This tutorial is an Python notebook which is a web-based interative 
environment where code, text and plots can be combined and the code 
snippets can be executed (and modified) directly.
IPython can be installed on Linux, Mac and Windows - please follow the 
instructions on http://ipython.org/install.html.

For Linux, the interactive IPython notebook can be started by typing
ipython notebook --pylab=inline
in the base directory with the TDT\ challenge\ tutorial.ipynb file.

Alternatively, we provide the tutorial as an HTML and PDF file.

Software
--------------------------------------

The tutorial was tested for Red Hat Linux.
The Python libraries used in the tutorial are also available for 
Mac and Windows. All libraries are open-source.

These Python libraries are available through pip, yum or apt-get:
- scipy
- numpy
- matplotlib
- aggdraw or cairo
- scikit-learn

The cheminformatics toolkit RDKit can be obtained from http://rdkit.org 
and installation instructions can be found here:
http://code.google.com/p/rdkit/w/list



TDT 2014 - Challenge 1
-----------------------------
Title: "Malaria High-Throughput Screen"


Tarball contents
----------------

- Tutorial
  "TDT_challenge_tutorial.ipynb"
  "TDT_challenge_tutorial.html"
  "TDT_challenge_tutorial.pdf"

- List of 500 actives from the primary screen selected for confirmatory assay
  (identifier, SMILES)
  "results/compounds_for_confirmatory_assay.txt"

- Rank-ordered list of compounds in the external test set
  (identifier, SMILES, max rank, max probability)
  "results/rank_ordered_list_external_testset.txt"

- Rank-ordered list of top-1000 commercial compounds predicted to be active
  (identifier, SMILES, max rank, max probability)
  "results/rank_ordered_list_commercial_cmps.txt"

The other folders contain all necessary scripts, input files and main
results produced during the workflow.

- data: contains the input data provided by the TDT challenge

- pains_filter: contains the PAINS SMARTS pattern obtained from
  http://www.macinchem.org/reviews/pains/painsFilter.php

- test_lists: contains the lists with the molecule indices selected for
  testing (50 repetitions)

- evaluation: contains the scripts and results for the model validation

- final_models: contains the scripts and final trained models

- hit_finding: contains the scripts and results for application of the trained
  models to a list of commercially available compounds obtained from eMolecules
