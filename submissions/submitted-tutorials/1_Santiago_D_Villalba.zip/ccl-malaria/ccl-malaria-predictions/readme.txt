Selected molecules for the TDT-malaria screening campaign challenge.
All files are CSV files with 3 columns: molid, smiles, score.
Note that the score is, in our case, unrelated to potency.
(well, we hope it is a little bit related, but just use it to rank...)
